import os
from ament_index_python.packages import get_package_share_directory, get_package_prefix
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch_ros.actions import Node, SetParameter
from launch.launch_description_sources import PythonLaunchDescriptionSource
import xacro



def generate_launch_description():
    ld = LaunchDescription()

    # Specify the name of the package and path to xacro file within the package
    pkg_name = 'alexander_fleming_description'
    file_subpath = 'urdf/alexander_fleming.urdf.xacro'

    # Set ignition resource path (to be able to render meshes)
    resource_paths = [os.path.join(get_package_prefix(pkg_name), 'share')]

    # Add any existing declared resources
    if 'IGN_GAZEBO_RESOURCE_PATH' in os.environ:
        resource_paths.insert(0, os.environ['IGN_GAZEBO_RESOURCE_PATH'])

    # Concatenate a path seperator (':') between all paths and update the environment variable
    ign_resource_path_update = SetEnvironmentVariable(name='IGN_GAZEBO_RESOURCE_PATH',value=[os.pathsep.join(resource_paths)])


    # Use xacro to process the URDF file
    xacro_file = os.path.join(get_package_share_directory(pkg_name),file_subpath)
    robot_description_raw = xacro.process_file(xacro_file).toxml()



    # Start simulation
    launch_sim_world = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('coursework_support'), 'launch'),
         '/sim_bringup.launch.py'])
      )


    # robot state publisher node
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description_raw}] # add other parameters here if required
    )

    # Run the spawner node from the gazebo_ros package. The entity name doesn't really matter if you only have a single robot.
    node_spawn_entity = Node(package='ros_gz_sim', executable='create',
                        arguments=['-topic', '/robot_description',
                                   '-z', '0.5'],
                        output='screen')
    
    node_joint_state_publisher = Node(
    package='joint_state_publisher',
    executable='joint_state_publisher',
    output='screen',
    parameters=[{'use_gui': False}]  
    )

    package_share_directory = get_package_share_directory('alexander_fleming_description')
    config_file = os.path.join(package_share_directory, 'config', 'mapper_params_online_async.yaml')

    # 定义 SLAM Toolbox 节点，加载自定义参数
    slam_toolbox_node = Node(
        package='slam_toolbox',                  # SLAM Toolbox 包名
        executable='async_slam_toolbox_node',    # 可执行文件名
        name='slam_toolbox',                     # 节点名称
        output='screen',                         # 输出到屏幕
        parameters=[config_file]                 # 使用自定义参数文件
    )


    config_file_path=os.path.join(package_share_directory, 'config', 'twist_mux.yaml')
    node_twist_mux = Node(
    package='twist_mux',
    executable='twist_mux',
    name='twist_mux',
    output='screen',
    parameters=[config_file_path],
    remappings=[
            ('cmd_vel_out', '/alexander_fleming/cmd_vel'),  # 输出重定向
        ],
)

    teleop_twist_keyboard_node = Node(
        package='teleop_twist_keyboard',
        executable='teleop_twist_keyboard',
        name='teleop_twist_keyboard_node',
        remappings=[
            ("/cmd_vel", "/teleop_cmd_vel")  # 键盘控制输出主题
        ],
        output='screen',
    )

    node_ros_gz_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=  [
                    '/clock'                           + '@rosgraph_msgs/msg/Clock'   + '[' + 'ignition.msgs.Clock',
                    '/model/alexander_fleming/cmd_vel'  + '@geometry_msgs/msg/Twist'   + '@' + 'ignition.msgs.Twist',
                    '/model/alexander_fleming/odometry' + '@nav_msgs/msg/Odometry'     + '[' + 'ignition.msgs.Odometry',
                    '/model/alexander_fleming/scan'     + '@sensor_msgs/msg/LaserScan' + '[' + 'ignition.msgs.LaserScan',
                    '/model/alexander_fleming/tf'       + '@tf2_msgs/msg/TFMessage'    + '[' + 'ignition.msgs.Pose_V',
                    '/model/alexander_fleming/imu'      + '@sensor_msgs/msg/Imu'       + '[' + 'ignition.msgs.IMU',
                    '/model/alexander_fleming/joint_state' + '@sensor_msgs/msg/JointState' + '[' + 'ignition.msgs.Model',
                    '/model/alexander_fleming/depth/image_raw' + '@sensor_msgs/msg/Image' + '[' + 'ignition.msgs.Image',
                    '/model/alexander_fleming/depth/camera_info' + '@sensor_msgs/msg/CameraInfo' + '[' + 'ignition.msgs.CameraInfo',
                    '/model/alexander_fleming/depth/points' + '@sensor_msgs/msg/PointCloud2' + '[' + 'ignition.msgs.PointCloudPacked',
                    ],
        parameters= [{'qos_overrides./alexander_fleming.subscriber.reliability': 'reliable'}],
        remappings= [
                    ('/model/alexander_fleming/cmd_vel',  '/alexander_fleming/cmd_vel'),
                    ('/model/alexander_fleming/odometry', '/odom_raw' ),
                    ('/model/alexander_fleming/scan',     '/scan'   ),
                    ('/model/alexander_fleming/tf',       '/tf'     ),
                    ('/model/alexander_fleming/imu',      '/imu_raw'),
                    ('/model/alexander_fleming/joint_state', 'joint_states'),
                    # ('/model/alexander_fleming/depth',          '/depth'),
                    ('/model/alexander_fleming/depth/image_raw', '/depth/image_raw'),
                    ('/model/alexander_fleming/depth/camera_info', '/depth/camera_info'),
                    ('/model/alexander_fleming/depth/points', '/depth/points'),
                    ],
        output='screen'
    )


    # Add actions to LaunchDescription
    ld.add_action(SetParameter(name='use_sim_time', value=True))
    ld.add_action(ign_resource_path_update)
    ld.add_action(node_robot_state_publisher)
        # SLAM Toolbox
    ld.add_action(slam_toolbox_node)    
    ld.add_action(teleop_twist_keyboard_node)
    ld.add_action(node_spawn_entity)
    ld.add_action(node_ros_gz_bridge)
    # ld.add_action(another_launch)
    ld.add_action(launch_sim_world)
    ld.add_action(node_joint_state_publisher)
    
    ld.add_action(node_twist_mux)
    return ld